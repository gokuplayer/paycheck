﻿using System;

class paycheckCalculator
{
    
    static void Main()
    {

        double wages;
        double hoursWorked;
        double salary;
        double federalIncomeTax;
        double flatFederalTax;
        double federalTaxes;
        double otherTaxes;
        double costOf401k;
        double stateIncomeTax = 5;
        double localIncomeTax = 0;
        double socialSecurity = 6.2;
        double medicare = 1.45;
        double retirementPlan;
        double grossIncome;
        double totalTaxPercent;
        double totalTaxes;
        double netIncome;

        string payPeriod;

        bool SalaryOrWages;
        bool repeat = true;

        while (repeat)
        {

            Console.Write("Do you have a salary (Y or N)? ");
            if (Console.ReadLine() == "Y")
            {

                SalaryOrWages = true;

            }
            else
            {

                SalaryOrWages = false;

            }

            Console.Write("How often are you paid (W, B, or M)? ");
            payPeriod = Console.ReadLine();

            if (SalaryOrWages)
            {

                Console.Write("Please enter your salary: ");
                salary = float.Parse(Console.ReadLine());

                if (payPeriod == "W")
                {

                    hoursWorked = 40;
                    grossIncome = salary / 52;

                }
                else if (payPeriod == "B")
                {

                    hoursWorked = 80;
                    grossIncome = salary / 26;

                }
                else if (payPeriod == "M")
                {

                    hoursWorked = 160;
                    grossIncome = salary / 12;

                }
                else
                {

                    hoursWorked = 40;
                    grossIncome = salary / 52;

                }

            }
            else
            {

                Console.Write("Please enter your hourly wages: ");
                wages = float.Parse(Console.ReadLine());

                Console.Write("Please enter your hours worked this pay period: ");
                hoursWorked = float.Parse(Console.ReadLine());

                grossIncome = wages * hoursWorked;

                salary = grossIncome * 52;
                salary = Math.Round(salary, 2);

            }

            grossIncome = Math.Round(grossIncome, 2);

            Console.Write("Please enter your 401k percentage: ");
            retirementPlan = float.Parse(Console.ReadLine());

            switch (salary)
            {

                case double i when i >= 0 && i <= 10275:
                    federalIncomeTax = 10;
                    flatFederalTax = 0;
                    federalTaxes = (((salary - 0) * (federalIncomeTax / 100)) + flatFederalTax) / 52;
                    break;
                case double i when i > 10275 && i <= 41775:
                    federalIncomeTax = 12;
                    flatFederalTax = 1027.50 / 52;
                    federalTaxes = (((salary - 0) * (federalIncomeTax / 100)) + flatFederalTax) / 52;
                    break;
                case double i when i > 41775 && i <= 89075:
                    federalIncomeTax = 22;
                    flatFederalTax = 4807.50 / 52;
                    federalTaxes = (((salary - 0) * (federalIncomeTax / 100)) + flatFederalTax) / 52;
                    break;
                case double i when i > 89075 && i <= 170050:
                    federalIncomeTax = 24;
                    flatFederalTax = 15213.50 / 52;
                    federalTaxes = (((salary - 0) * (federalIncomeTax / 100)) + flatFederalTax) / 52;
                    break;
                case double i when i > 170050 && i <= 215950:
                    federalIncomeTax = 32;
                    flatFederalTax = 34647.50 / 52;
                    federalTaxes = (((salary - 0) * (federalIncomeTax / 100)) + flatFederalTax) / 52;
                    break;
                case double i when i > 215950 && i <= 539900:
                    federalIncomeTax = 35;
                    flatFederalTax = 49335.50 / 52;
                    federalTaxes = (((salary - 0) * (federalIncomeTax / 100)) + flatFederalTax) / 52;
                    break;
                case double i when i > 539900:
                    federalIncomeTax = 37;
                    flatFederalTax = 162718 / 52;
                    federalTaxes = (((salary - 0) * (federalIncomeTax / 100)) + flatFederalTax) / 52;
                    break;
                default:
                    federalIncomeTax = 10;
                    flatFederalTax = 0;
                    federalTaxes = (((salary - 0) * (federalIncomeTax / 100)) + flatFederalTax) / 52;
                    break;

            }

            federalTaxes = Math.Round(federalTaxes, 2);
            otherTaxes = grossIncome * ((stateIncomeTax + localIncomeTax + socialSecurity + medicare) / 100);
            otherTaxes = Math.Round(otherTaxes, 2);
            costOf401k = (grossIncome * retirementPlan) / 52;
            costOf401k = Math.Round(costOf401k, 2);
            totalTaxes = federalTaxes + otherTaxes + costOf401k;
            totalTaxes = Math.Round(totalTaxes, 2);
            totalTaxPercent = (totalTaxes / grossIncome) * 100;
            totalTaxPercent = Math.Round(totalTaxPercent, 2);
            netIncome = grossIncome - totalTaxes;
            netIncome = Math.Round(netIncome, 2);

            Console.WriteLine("Predicted Gross Income: " + "$" + grossIncome.ToString());
            Console.WriteLine("Predicted Yearly Salary: " + "$" + salary.ToString());
            Console.WriteLine("Predicted Federal Taxes: " + "$" + (federalTaxes).ToString());
            Console.WriteLine("Predicted Miscellaneous Taxes: " + "$" + (otherTaxes).ToString());
            Console.WriteLine("Predicted 401k: " + "$" + (costOf401k).ToString());
            Console.WriteLine("Predicted Taxes Taken Out: " + "$" + totalTaxes.ToString());
            Console.WriteLine("Predicted Tax Percentage: " + totalTaxPercent.ToString() + "%");
            Console.WriteLine("Predicted Paycheck: " + "$" + netIncome.ToString());

            Console.Write("Would you like to continue (Y or N)? ");
            if(Console.ReadLine() == "Y")
            {

                repeat = true;

            }
            else
            {

                repeat = false;

            }

        }

    }
}